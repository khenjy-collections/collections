<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->model('CRUD_Model');
  }

  public function index(){
    $data = array(
      'konten' => "v_product",
      'title' => 'Halaman Home',
      'produk' => $this->CRUD_Model->tampil_data('product')->result()
    );

    $this->load->view("beranda",$data);
  }

  public function berita(){
    //buat array
    $data = array(
      'konten' => "berita",
      'title' => 'Halaman Berita'
    );

    //panggil view dan kirim nilai array data
    $this->load->view("beranda",$data);
  }

  public function gallery(){

  }
}