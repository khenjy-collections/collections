<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends CI_Controller { 

  
  public function __construct()
  {
    parent::__construct();
    $this->load->model("CRUD_Model");
  }
  

  public function simpan(){

    //tampung data yang dikirm dr form dalam array
    $data = array(
      'kd_produk' => '',
      'nama_produk' => $this->input->post('txtnama'),
      'kategori_produk' => $this->input->post('cbokategori'),
      'ukuran_produk' => $this->input->post('cboukuran'),
      'stok_produk' => $this->input->post('txtstok'),
      'harga_produk' => $this->input->post('txtharga'),
      'foto_produk' => ''
    );

    //kirim data array ke dalam model
    $this->CRUD_Model->fungsi_simpan('product',$data);

  

  }
}