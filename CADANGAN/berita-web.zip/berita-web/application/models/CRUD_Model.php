<?php
defined('BASEPATH') or exit('No direct script access allowed');
class CRUD_Model extends CI_Model{

  public function fungsi_simpan($tabel,$data){
     return $this->db->insert($tabel,$data);
     //insert('namatabel','data yang mau disimpan')
    //insert into product value dan kolom di database diambil dr array $data
  }

  public function tampil_data($tabel){
    return $this->db->get($tabel);
    //select * from produk
  }

}