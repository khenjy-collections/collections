<div class="container">
<h3>Produk Baru</h3>
<div class="row">
  <div class="col-12">
  <form action="<?php echo site_url("produk/simpan") ?>" method="post" >
  
  <div class="form-group">
    <label for="nama">Nama</label>
    <input type="text" class="form-control" id="nama" name="txtnama">
    <small id="nama" class="form-text text-muted">nama produk</small>
  </div>

  <div class="form-group">
    <label for="kategori">Kategori Produk</label>
    <select name="cbokategori" class="custom-select"> 
      <option>Pilih Kategori Pakaian</option>
      <?php 
        $kategori = array("tshirt","shorts","hoodie","sweatshirt");
        foreach($kategori as $k){
          echo "<option value='$k'>$k</option>";
        }
      ?>
      </select>
    <small id="nama" class="form-text text-muted">Kategori produk</small>
  </div>

  <div class="form-group">
    <label for="kategori">Ukuran Produk</label>
    <select name="cboukuran" class="custom-select col-1"> 
      <?php
      $ukuran = array('S','M','L','XL');
        foreach($ukuran as $u){
          echo "<option value='$u'>$u</option>";
        }
      ?>
    </select>
    <small id="nama" class="form-text text-muted">Ukuran produk</small>
  </div>


  <div class="form-group">
    <label for="stok">Stok</label>
    <input type="text" class="form-control" id="stok" name="txtstok">
    <small id="nama" class="form-text text-muted">Stok</small>
  </div>

  <div class="form-group">
    <label for="harga">Harga Produk</label>
    <input type="text" class="form-control" id="harga" name="txtharga">
    <small id="nama" class="form-text text-muted">Harga Produk</small>
  </div>

  <button type="submit" class="btn btn-primary">Simpan</button>
  <button type="reset" class="btn btn-danger">Batal</button>
  
  </form>
 
  </div>
</div>
</div>