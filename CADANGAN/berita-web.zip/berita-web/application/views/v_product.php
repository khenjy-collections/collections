<link rel="stylesheet" href="<?php echo base_url("assets/css/style.css"); ?>"> 

<style>
.kuning{
  color: yellow;
}
</style>
<div class="col-12">
<h3 id="judul">Data Produk</h3>
<div class="col-12"><a href='#' class="btn btn-primary kuning">Tambah Data</a></div>
<table class="table table-hover mt-3">
  <thead>
    <th>Kode produk</th>
    <th>Nama Produk</th>
    <th>Kategori</th>
    <th>Ukuran</th>
    <th>Stok</th>
    <th>Harga</th>
    <th>Foto Produk</th>
    <th style="color:blue">Aksi</th>
  </thead>
  <tbody>
  <?php
      foreach($produk as $p){ ?>
        
        <!-- ini bagian yang kita lakukan perulangan -->
        <tr>
         <td><?php echo $p->kd_produk; ?></td>
         <td><?php echo $p->nama_produk; ?></td>
         <td><?php echo $p->kategori_produk; ?></td>
         <td><?php echo $p->ukuran_produk; ?></td>
         <td><?php echo $p->stok_produk; ?></td>
         <td><?php echo $p->harga_produk; ?></td>
         <td><?php echo $p->foto_produk; ?></td>
         <td>edit | delete | view</td>
        </tr>

    <?php } ?>
    
  </tbody>
</table>
</div>