# crud-android-studio-daftar-mahasiswa
repo belajar crud studi kasus daftar mahasiswa

repository untuk tugas pemrograman 5
universitas muhammadiyah banten

design bisa dilihat di
https://www.figma.com/file/c9y1ZvZX3PonN9VwcXWhbY/project-daftar-mahasiswa?node-id=0%3A1

